<?php
namespace Core;

interface PluginInterface {
    public function register(Kernel $kernel): void;
    public function handle(array $request): array;
    public function getManifest(): array; // Returns name, version, dependencies
}