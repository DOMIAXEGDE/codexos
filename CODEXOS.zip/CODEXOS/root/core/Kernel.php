<?php
namespace Core;

class Kernel {
    private array $plugins = [];
    private array $config = [];
    private string $projectRoot;

    public function __construct(string $rootPath) {
        $this->projectRoot = $rootPath;
        $this->loadGlobalConfig();
    }

    private function loadGlobalConfig(): void {
        $path = $this->projectRoot . '/config.global.json';
        if (file_exists($path)) {
            $this->config = json_decode(file_get_contents($path), true);
        }
    }

    public function loadPlugins(): void {
        $pluginDir = $this->projectRoot . '/plugins';
        foreach (glob($pluginDir . '/*', GLOB_ONLYDIR) as $dir) {
            $pluginName = basename($dir);
            $className = "Plugins\\{$pluginName}\\{$pluginName}";
            $file = $dir . "/{$pluginName}.php";
            
            if (file_exists($file)) {
                require_once $file;
                if (class_exists($className)) {
                    $plugin = new $className();
                    if ($plugin instanceof PluginInterface) {
                        $this->plugins[$pluginName] = $plugin;
                        $plugin->register($this);
                    }
                }
            }
        }
    }

    public function dispatch(string $target, array $payload): array {
        if (isset($this->plugins[$target])) {
            return $this->plugins[$target]->handle($payload);
        }
        return ['status' => 'error', 'message' => "Plugin {$target} not loaded."];
    }

    public function getPath(string $type): string {
        return match($type) {
            'data' => $this->projectRoot . '/data',
            'bin'  => $this->projectRoot . '/bin',
            default => $this->projectRoot
        };
    }
}