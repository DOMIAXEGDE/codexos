<?php
namespace Plugins\DataViewer;

use Core\Kernel;
use Core\PluginInterface;

class DataViewer implements PluginInterface {
    private Kernel $kernel;

    public function register(Kernel $kernel): void {
        $this->kernel = $kernel;
    }

    public function getManifest(): array {
        return [
            'name' => 'DataViewer',
            'version' => '1.0.0',
            'description' => 'Secure Read-Only Access to the /data Partition'
        ];
    }

    public function handle(array $request): array {
        $action = $request['action'] ?? 'list';
        $target = $request['target'] ?? '';

        return match($action) {
            'list' => $this->listFiles(),
            'read' => $this->readFile($target),
            default => ['status' => 'error', 'message' => 'Unknown I/O Action']
        };
    }

    private function listFiles(): array {
        $dataDir = $this->kernel->getPath('data');
        $files = [];
        
        // Scan for specific data types
        foreach (glob($dataDir . '/*.{txt,json}', GLOB_BRACE) as $path) {
            $files[] = [
                'name' => basename($path),
                'size' => $this->formatBytes(filesize($path)),
                'modified' => date('Y-m-d H:i:s', filemtime($path))
            ];
        }

        return ['status' => 'success', 'files' => $files];
    }

    private function readFile(string $filename): array {
        // Security: Rigidly sanitize filename to prevent traversal
        $cleanName = basename($filename); 
        $path = $this->kernel->getPath('data') . '/' . $cleanName;

        if (!file_exists($path)) {
            return ['status' => 'error', 'message' => 'File not found via Kernel I/O'];
        }

        // Limit read size to prevent memory overflow on large permutations
        $content = file_get_contents($path, false, null, 0, 10000); 
        $isTruncated = filesize($path) > 10000;

        return [
            'status' => 'success',
            'file' => $cleanName,
            'content' => $content . ($isTruncated ? "\n\n[...Stream Truncated by Kernel...]" : "")
        ];
    }

    private function formatBytes($bytes, $precision = 2) {
        $units = ['B', 'KB', 'MB', 'GB'];
        $bytes = max($bytes, 0);
        $pow = floor(($bytes ? log($bytes) : 0) / log(1024));
        $pow = min($pow, count($units) - 1);
        return round($bytes / pow(1024, $pow), $precision) . ' ' . $units[$pow];
    }
}