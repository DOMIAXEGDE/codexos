<?php
namespace Plugins\PipelineEngine;

use Core\Kernel;
use Core\PluginInterface;

class PipelineEngine implements PluginInterface {
    private Kernel $kernel;
    private array $runtimeConfig = [];

    // 1. Rigid Initialization
    public function register(Kernel $kernel): void {
        $this->kernel = $kernel;
    }

    public function getManifest(): array {
        return [
            'name' => 'PipelineEngine',
            'version' => '1.1.0',
            'description' => 'Orchestrates the Prompt-to-Response execution cycle.'
        ];
    }

    // 2. The Execution Flow (The Algorithm)
    public function handle(array $request): array {
        // Determine the input vector
        $prompt = $request['prompt'] ?? '';
        if (empty($prompt)) {
            return ['status' => 'error', 'message' => 'Empty prompt input.'];
        }

        // 1. SYSTEM COMMAND INTERCEPT: Batch Ingestion
        // Rigid Syntax: "ingest batch [filename]"
        if (str_starts_with(strtolower($prompt), 'ingest batch')) {
            return $this->executeBatch($prompt);
        }

        // Load the current "Tape" (Configuration)
        $this->loadRuntimeConfig();

        // A. INGEST & TOKENIZATION
        $tokens = $this->tokenize($prompt);

        // B. INTENT DETECTION (Pattern Matching)
        $intent = $this->detectIntent($prompt);

        // C. RESPONSE GENERATION
        $response = $this->generateResponse($prompt, $intent);

        // D. LEARNING (Delta Generation)
        $delta = $this->calculateDelta($tokens, $intent);
        
        // E. SIDE EFFECTS (Persistence)
        $archiveId = $this->archiveTransaction($prompt, $response, $intent, $delta);
        
        // F. STATE MUTATION (Self-modification)
        if (!empty($delta)) {
            $this->kernel->dispatch('ConfigManager', ['action' => 'delta', 'delta' => $delta]);
        }

        return [
            'status' => 'success',
            'data' => [
                'prompt' => $prompt,
                'response' => $response,
                'intent' => $intent,
                'tokens' => [
                    'count' => count($tokens),
                    'list' => $tokens
                ],
                'delta' => $delta,
                'archive_id' => $archiveId
            ]
        ];
    }

    // --- NEW: Batch Processor Logic ---
    private function executeBatch(string $command): array {
        // 1. Parse Filename
        $parts = explode(' ', $command, 3);
        $filename = trim($parts[2] ?? '');
        
        if (empty($filename)) {
            return ['status' => 'error', 'message' => 'Filename required. Usage: ingest batch <filename>'];
        }

        // 2. Secure Path Resolution
        $cleanName = basename($filename); // Prevent directory traversal
        $path = $this->kernel->getPath('data') . '/' . $cleanName;

        if (!file_exists($path)) {
            return ['status' => 'error', 'message' => "File not found: $cleanName"];
        }

        // 3. Stream Processing (Memory Efficient)
        $handle = fopen($path, "r");
        if (!$handle) {
            return ['status' => 'error', 'message' => "Could not open file."];
        }

        $learnedCount = 0;
        $batchDelta = ['frequencyMap' => []];

        while (($line = fgets($handle)) !== false) {
            // Skip comments and empty lines
            if (str_starts_with($line, '#') || trim($line) === '') continue;

            // Parse Structure: index|token|role|weight|tags
            $cols = explode('|', $line);
            
            // Validate LLML format (Must have at least 2 columns: ID and Token)
            if (count($cols) >= 2) {
                $token = trim($cols[1]);
                
                // Accumulate Frequency
                if (!empty($token)) {
                    if (!isset($batchDelta['frequencyMap'][$token])) {
                        $batchDelta['frequencyMap'][$token] = 0;
                    }
                    $batchDelta['frequencyMap'][$token]++;
                    $learnedCount++;
                }
            }
        }
        fclose($handle);

        // 4. Commit to Memory (The Learning Step)
        if ($learnedCount > 0) {
            $this->kernel->dispatch('ConfigManager', ['action' => 'delta', 'delta' => $batchDelta]);
        }

        // 5. Archive the Event
        $archiveId = $this->archiveTransaction(
            $command, 
            "Batch Ingestion Complete. Processed $learnedCount tokens.", 
            "system_batch", 
            ['learned_tokens' => $learnedCount] // Summary delta only, to save space
        );

        return [
            'status' => 'success',
            'data' => [
                'prompt' => $command,
                'response' => "Ingestion complete. The system learned $learnedCount new pattern weights.",
                'intent' => 'system_batch',
                'tokens' => ['count' => 0, 'list' => []],
                'delta' => $batchDelta, // Visual feedback for the UI
                'archive_id' => $archiveId
            ]
        ];
    }

    // --- Internal Logic Modules ---

    private function loadRuntimeConfig(): void {
        // Fetch the latest state from the ConfigManager
        $result = $this->kernel->dispatch('ConfigManager', ['action' => 'get']);
        $this->runtimeConfig = $result['config'] ?? [];
    }

    private function tokenize(string $text): array {
        // Standardize input
        $text = strtolower(trim($text));
        // Simple regex tokenizer (can be swapped for C-binary call if performance required)
        return str_word_count($text, 1);
    }

    private function detectIntent(string $prompt): string {
        $promptLower = strtolower($prompt);
        $weights = $this->runtimeConfig['intentWeights'] ?? [];
        
        // Dynamic intent matching based on Config weights
        $bestIntent = 'general';
        $highestWeight = 0;

        foreach ($weights as $keyword => $weight) {
            if (str_contains($promptLower, $keyword)) {
                if ($weight > $highestWeight) {
                    $highestWeight = $weight;
                    $bestIntent = $keyword;
                }
            }
        }
        
        // Fallback for hardcoded common verbs if config is empty
        if ($bestIntent === 'general') {
             if (str_contains($promptLower, 'explain')) return 'explain';
             if (str_contains($promptLower, 'define')) return 'define';
             if (str_contains($promptLower, 'run')) return 'execute';
             // NEW: Explicitly link "generate" to the Permutation Drive
             if (str_contains($promptLower, 'generate')) return 'permute';
        }

        return $bestIntent;
    }

    private function generateResponse(string $prompt, string $intent): string {
        // 1. Check if we should use the PermutationDrive (C Binary)
        if ($intent === 'permute' || str_contains($prompt, 'generate tokens')) {
            $result = $this->kernel->dispatch('PermutationDrive', ['action' => 'generate_responses']);
            return $result['status'] === 'success' ? "Permutation generation initiated." : "Generation failed.";
        }

        // 2. Use Configurable Patterns
        $patterns = $this->runtimeConfig['responsePatterns'] ?? [];
        $pattern = $patterns[$intent] ?? $patterns['default'] ?? '{content}';
        
        // Simple slot filling
        return str_replace('{content}', "Processed: " . htmlspecialchars($prompt), $pattern);
    }

    private function calculateDelta(array $tokens, string $intent): array {
        $delta = [];

        // 1. Frequency Analysis (Hebb's Rule: Cells that fire together, wire together)
        // We increment the weight of seen tokens.
        if (!isset($delta['frequencyMap'])) {
            $delta['frequencyMap'] = [];
        }
        foreach ($tokens as $token) {
            $delta['frequencyMap'][$token] = 1; // ConfigManager handles the accumulation logic
        }

        // 2. Intent Reinforcement
        // If a specific intent was triggered, verify if we should strengthen it
        // (This is a simplified placeholder for Reinforcement Learning)
        // $delta['intentWeights'][$intent] = 0.01; 

        return $delta;
    }

    private function archiveTransaction(string $prompt, string $response, string $intent, array $delta): string {
        $id = 'run_' . microtime(true) . '_' . bin2hex(random_bytes(4));
        
        $record = [
            'id' => $id,
            'timestamp' => date('c'),
            'prompt' => $prompt,
            'response' => $response,
            'intent' => $intent,
            'config_delta' => $delta,
            'domain' => 'general' // Could be derived from ModuleRegistry
        ];

        $path = $this->kernel->getPath('data') . '/archives/' . $id . '.json';
        file_put_contents($path, json_encode($record, JSON_PRETTY_PRINT));
        
        return $id;
    }
}