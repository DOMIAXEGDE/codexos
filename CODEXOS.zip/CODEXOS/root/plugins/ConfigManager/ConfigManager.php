<?php
namespace Plugins\ConfigManager;

use Core\Kernel;
use Core\PluginInterface;
use stdClass;

class ConfigManager implements PluginInterface {
    private Kernel $kernel;
    private string $configPath;
    private array $state = [];

    // 1. Rigid Initialization
    public function register(Kernel $kernel): void {
        $this->kernel = $kernel;
        // The config lives in the /data directory for persistence
        $this->configPath = $this->kernel->getPath('data') . '/llm_config.json';
        $this->loadState();
    }

    public function getManifest(): array {
        return [
            'name' => 'ConfigManager', 
            'version' => '2.0.0',
            'description' => 'Dynamic State Machine & Memory Persistence'
        ];
    }

    // 2. The Central Dispatch (Operable Interface)
    public function handle(array $request): array {
        $action = $request['action'] ?? 'get';
        
        return match($action) {
            'get'            => ['status' => 'success', 'config' => $this->state],
            'update'         => $this->updateFull($request['config'] ?? []),
            'delta'          => $this->applyDelta($request['delta'] ?? []),
            'log_frequency'  => $this->updateFrequency($request['content'] ?? ''),
            'reset'          => $this->resetToDefault(),
            default          => ['status' => 'error', 'message' => 'Unknown Config Action']
        };
    }

    // 3. State Persistence (I/O)
    private function loadState(): void {
        if (!file_exists($this->configPath)) {
            $this->resetToDefault();
        } else {
            $content = file_get_contents($this->configPath);
            $this->state = json_decode($content, true) ?? [];
        }
    }

    private function saveState(): void {
        // Atomic write to prevent corruption
        $tempPath = $this->configPath . '.tmp';
        file_put_contents($tempPath, json_encode($this->state, JSON_PRETTY_PRINT));
        rename($tempPath, $this->configPath);
    }

    // 4. Turing Complete Feature: Self-Modification via Delta
    // This allows the system to rewrite its own rules at runtime.
    private function applyDelta(array|string $delta): array {
        if (is_string($delta)) {
            $delta = json_decode($delta, true) ?? [];
        }

        // Recursive merging logic derived from original atomicConfig
        foreach ($delta as $key => $value) {
            // If both are arrays, merge them (Arrays describe lists/stacks)
            if (is_array($value) && isset($this->state[$key]) && is_array($this->state[$key])) {
                 // Check if associative (treating as object) or sequential
                 if ($this->isAssoc($value)) {
                     $this->state[$key] = array_replace_recursive($this->state[$key], $value);
                 } else {
                     $this->state[$key] = array_merge($this->state[$key], $value);
                 }
            } 
            // Otherwise, overwrite (Scalars describe variables/pointers)
            else {
                $this->state[$key] = $value;
            }
        }

        $this->saveState();
        return ['status' => 'success', 'config' => $this->state, 'delta_applied' => true];
    }

    // 5. Self-Learning: Frequency Mapping
    // Updates the statistical probability map based on user input.
    private function updateFrequency(string $content): array {
        if (empty($content)) return ['status' => 'skipped'];

        $words = str_word_count(strtolower($content), 1);
        
        if (!isset($this->state['frequencyMap'])) {
            $this->state['frequencyMap'] = [];
        }

        foreach ($words as $word) {
            if (!isset($this->state['frequencyMap'][$word])) {
                $this->state['frequencyMap'][$word] = 0;
            }
            $this->state['frequencyMap'][$word]++;
        }

        $this->saveState();
        return ['status' => 'success', 'learned_tokens' => count($words)];
    }

    private function updateFull(array $newConfig): array {
        $this->state = $newConfig;
        $this->saveState();
        return ['status' => 'success', 'message' => 'Configuration replaced'];
    }

    private function resetToDefault(): array {
        // Default structure mirroring the original llml-atomicConfig.php defaults
        $this->state = [
            'frequencyMap' => new stdClass(),
            'responsePatterns' => [
                'explain' => 'Here is an explanation: {content}',
                'default' => '{content}'
            ],
            'intentWeights' => [
                'explain' => 0.8,
                'summarize' => 0.7
            ],
            'moduleRegistry' => [],
            'modelParams' => [
                'threshold' => 0.7,
                'maxTokens' => 1000
            ]
        ];
        $this->saveState();
        return ['status' => 'reset', 'config' => $this->state];
    }

    private function isAssoc(array $arr): bool {
        if (array() === $arr) return false;
        return array_keys($arr) !== range(0, count($arr) - 1);
    }
}