<?php
namespace Plugins\PermutationDrive;

use Core\Kernel;
use Core\PluginInterface;

class PermutationDrive implements PluginInterface {
    private Kernel $kernel;

    // 1. Rigid Initialization
    public function register(Kernel $kernel): void {
        $this->kernel = $kernel;
    }

    public function getManifest(): array {
        return [
            'name' => 'PermutationDrive', 
            'version' => '1.2.0',
            'description' => 'Interface for Compiled C-Binary Permutation Generators (Cross-Platform)'
        ];
    }

    // 2. Dispatcher
    public function handle(array $request): array {
        $action = $request['action'] ?? '';
        
        return match($action) {
            'generate_prompts' => $this->execBinary('prompts'),
            'generate_responses' => $this->execBinary('responses'),
            default => ['status' => 'error', 'message' => "Unknown PermutationDrive action: $action"]
        };
    }

    // 3. The Engine Room
    private function execBinary(string $subfolder): array {
        // A. Detect OS for Extension (Windows requires .exe)
        $isWindows = (strtoupper(substr(PHP_OS, 0, 3)) === 'WIN');
        $extension = $isWindows ? '.exe' : '';

        // B. Construct Granular Path
        // /llm_lab_root/bin/responses/generator.exe
        $binRoot = $this->kernel->getPath('bin');
        $binPath = $binRoot . DIRECTORY_SEPARATOR . $subfolder . DIRECTORY_SEPARATOR . 'generator' . $extension;

        // C. Define Output Context (The Data Directory)
        $dataDir = $this->kernel->getPath('data');

        // Validation
        if (!file_exists($binPath)) {
            return [
                'status' => 'error', 
                'message' => "Binary engine not found. Expected at: $binPath"
            ];
        }

        // D. Execution Command Construction
        // We CD into the data directory first so the C-code writes the .txt file there.
        // Windows and *nix both support '&&' for command chaining in this context.
        if ($isWindows) {
            // Windows specific quoting and cd /d for drive safety
            $cmd = 'cd /d ' . escapeshellarg($dataDir) . ' && ' . escapeshellarg($binPath);
        } else {
            // Standard *nix
            $cmd = 'cd ' . escapeshellarg($dataDir) . ' && ' . escapeshellarg($binPath);
        }

        // E. Fire the Engine
        $output = [];
        $returnVar = 0;
        exec("$cmd 2>&1", $output, $returnVar);

        if ($returnVar !== 0) {
            return [
                'status' => 'error', 
                'message' => "Binary execution failed (Code $returnVar)",
                'details' => $output
            ];
        }

        return [
            'status' => 'success', 
            'message' => "Permutation Drive active. Generated data in /data via {$subfolder} engine.",
            'details' => $output
        ];
    }
}