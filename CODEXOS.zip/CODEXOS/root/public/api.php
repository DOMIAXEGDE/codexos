<?php
require_once __DIR__ . '/../core/PluginInterface.php';
require_once __DIR__ . '/../core/Kernel.php';

use Core\Kernel;

header('Content-Type: application/json');

// 1. Initialize Kernel
$kernel = new Kernel(realpath(__DIR__ . '/..'));
$kernel->loadPlugins();

// 2. Parse Request
$request = $_REQUEST;
$targetPlugin = $request['plugin'] ?? null;
$payload = $request['payload'] ?? [];

if (!$targetPlugin) {
    echo json_encode(['status' => 'error', 'message' => 'No plugin specified']);
    exit;
}

// 3. Dispatch to Modular Logic
$response = $kernel->dispatch($targetPlugin, $payload);

echo json_encode($response);