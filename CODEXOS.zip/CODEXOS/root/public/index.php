<?php
// llm-lab-shell.php - The Visual Terminal
// Serves the frontend interface for the Modular Kernel
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>LLM Lab OS // Kernel Shell</title>
    <style>
        :root {
            --bg-core: #1a1a1a;
            --bg-panel: #252525;
            --text-main: #e0e0e0;
            --text-dim: #888;
            --accent: #4CAF50;
            --accent-dim: #2E7D32;
            --border: #333;
            --font-mono: 'Fira Code', 'Consolas', monospace;
        }

        * { box-sizing: border-box; margin: 0; padding: 0; }
        
        body {
            background: var(--bg-core);
            color: var(--text-main);
            font-family: -apple-system, BlinkMacSystemFont, sans-serif;
            height: 100vh;
            overflow: hidden;
            display: grid;
            grid-template-columns: 1fr 400px; /* Main Term | Memory Panel */
        }

        /* UTILITY & LAYOUT */
        .panel { background: var(--bg-panel); display: flex; flex-direction: column; }
        .scroll { overflow-y: auto; scrollbar-width: thin; }
        .mono { font-family: var(--font-mono); }
        
        /* HEADER */
        header {
            grid-column: 1 / -1;
            height: 50px;
            border-bottom: 1px solid var(--border);
            display: flex;
            align-items: center;
            padding: 0 20px;
            justify-content: space-between;
            background: #202020;
        }
        .system-status { display: flex; gap: 20px; font-size: 0.8rem; }
        .status-dot { width: 8px; height: 8px; border-radius: 50%; background: var(--text-dim); display: inline-block; margin-right: 5px; }
        .status-dot.active { background: var(--accent); box-shadow: 0 0 8px var(--accent); }

        /* TERMINAL (Chat) */
        #terminal {
            padding: 20px;
            display: flex;
            flex-direction: column;
            gap: 15px;
        }
        .line { display: flex; gap: 15px; line-height: 1.5; font-size: 0.95rem; }
        .line.user .content { color: #fff; }
        .line.system .content { color: var(--accent); }
        .meta { font-size: 0.75rem; color: var(--text-dim); min-width: 60px; text-align: right; margin-top: 4px; }
        
        /* INPUT AREA */
        .input-deck {
            border-top: 1px solid var(--border);
            padding: 20px;
            background: var(--bg-panel);
        }
        textarea {
            width: 100%;
            background: #111;
            border: 1px solid var(--border);
            color: white;
            padding: 15px;
            border-radius: 4px;
            resize: none;
            height: 80px;
            outline: none;
        }
        textarea:focus { border-color: var(--accent); }
        .controls { display: flex; justify-content: space-between; margin-top: 10px; }
        button {
            background: var(--accent-dim);
            color: white;
            border: none;
            padding: 8px 16px;
            border-radius: 3px;
            cursor: pointer;
            font-weight: 600;
            transition: background 0.2s;
        }
        button:hover { background: var(--accent); }

        /* MEMORY PANEL (Right Side) */
        #memory-matrix {
            border-left: 1px solid var(--border);
            font-size: 0.85rem;
        }
        .tabs { display: flex; border-bottom: 1px solid var(--border); }
        .tab {
            flex: 1;
            text-align: center;
            padding: 12px;
            cursor: pointer;
            background: #2a2a2a;
            border: none;
            color: var(--text-dim);
        }
        .tab.active { background: var(--bg-panel); color: var(--accent); border-bottom: 2px solid var(--accent); }
        
        .data-view { padding: 15px; display: none; }
        .data-view.active { display: block; }
        
        .json-block {
            background: #151515;
            padding: 10px;
            border-radius: 4px;
            color: #a5d6a7;
            white-space: pre-wrap;
            font-size: 0.75rem;
        }
        
        /* Delta Visualization */
        .delta-pulse { animation: flash 1s ease-out; }
        @keyframes flash {
            0% { background-color: rgba(76, 175, 80, 0.3); }
            100% { background-color: transparent; }
        }

    </style>
</head>
<body>

    <header>
        <div class="logo mono">LLM_LAB // OS_KERNEL_V1</div>
        <div class="system-status mono">
            <span><span class="status-dot" id="status-kernel"></span>KERNEL</span>
            <span><span class="status-dot" id="status-memory"></span>MEMORY</span>
            <span>TOKENS: <span id="token-counter">0</span></span>
        </div>
    </header>

    <div class="panel scroll" id="terminal-panel">
        <div id="terminal">
            <div class="line system">
                <div class="meta">SYS</div>
                <div class="content mono">System Initialized. Plugins Loaded. Waiting for input...</div>
            </div>
        </div>
    </div>

    <div class="panel" id="memory-matrix">
        <div class="tabs mono">
            <div class="tab active" onclick="ui.switchTab('live')">LIVE STATE</div>
            <div class="tab" onclick="ui.switchTab('delta')">DELTA</div>
            <div class="tab" onclick="ui.switchTab('archive')">ARCHIVE</div>
            <div class="tab" onclick="ui.switchTab('drive'); os.loadDrive()">DRIVE</div>
        </div>

        <div id="view-live" class="data-view active scroll">
            <div class="mono" style="margin-bottom: 10px; color: var(--text-dim)">ConfigManager State</div>
            <div id="state-display" class="json-block mono">Loading...</div>
        </div>

        <div id="view-delta" class="data-view scroll">
            <div class="mono" style="margin-bottom: 10px; color: var(--text-dim)">Last Learning Cycle</div>
            <div id="delta-display" class="json-block mono">No delta yet.</div>
        </div>

        <div id="view-archive" class="data-view scroll">
             <div class="mono" style="margin-bottom: 10px; color: var(--text-dim)">Recent Transactions</div>
             <div id="archive-list"></div>
        </div>
        <div id="view-drive" class="data-view scroll">
            <div class="mono" style="margin-bottom: 10px; color: var(--text-dim)">/data Partition</div>
            <div id="drive-file-list" style="margin-bottom: 15px; border-bottom: 1px solid #333; padding-bottom: 10px;"></div>
            <div class="mono" style="margin-bottom: 5px; color: var(--text-dim)">Content Preview:</div>
            <div id="drive-content" class="json-block mono" style="color: #81d4fa">Select a file...</div>
        </div>
    </div>

    <div class="input-deck">
        <textarea id="input-source" class="mono" placeholder="Enter prompt command... [Ctrl+Enter to Execute]"></textarea>
        <div class="controls">
            <div class="mono" style="font-size: 0.8rem; color: var(--text-dim); margin-top: 5px;">
                Active Plugin: <span style="color: var(--accent)">PipelineEngine</span>
            </div>
            <button onclick="os.execute()">EXECUTE_PIPELINE</button>
        </div>
    </div>

<script>
/**
 * CLIENT OS KERNEL
 * Handles binding between UI and the PHP API Gateway
 */
const os = {
    state: {
        config: {},
        stats: { tokens: 0 },
        lastDelta: null
    },

    // The Comm Link
    dispatch: async (plugin, payload = {}) => {
        const formData = new FormData();
        formData.append('plugin', plugin);
        
        // Flatten payload for PHP
        for (const [key, value] of Object.entries(payload)) {
            formData.append(`payload[${key}]`, typeof value === 'object' ? JSON.stringify(value) : value);
        }

        try {
            ui.setStatus('kernel', true);
            const req = await fetch('api.php', { method: 'POST', body: formData });
            const res = await req.json();
            ui.setStatus('kernel', false);
            return res;
        } catch (e) {
            console.error("Kernel Panic:", e);
            ui.print('SYS', 'Kernel Panic: API Unreachable', true);
            return { status: 'error' };
        }
    },

    // Boot Sequence
    init: async () => {
        // Fetch initial brain state
        const res = await os.dispatch('ConfigManager', { action: 'get' });
        if (res.status === 'success') {
            os.state.config = res.config;
            ui.renderState();
            ui.setStatus('memory', true);
        }
        
        // Setup Hotkeys
        document.getElementById('input-source').addEventListener('keydown', (e) => {
            if (e.key === 'Enter' && e.ctrlKey) os.execute();
        });
    },
	
    // Inside const os = { ... }

    loadDrive: async () => {
        const res = await os.dispatch('DataViewer', { action: 'list' });
        if (res.status === 'success') {
            const list = document.getElementById('drive-file-list');
            list.innerHTML = '';
            
            res.files.forEach(f => {
                const row = document.createElement('div');
                row.className = 'mono';
                row.style.padding = '4px 0';
                row.style.cursor = 'pointer';
                row.style.fontSize = '0.8rem';
                row.innerHTML = `<span style="color:var(--accent)">${f.name}</span> <span style="color:#666">(${f.size})</span>`;
                
                row.onclick = async () => {
                    ui.print('SYS', `Reading ${f.name} from /data...`);
                    const readRes = await os.dispatch('DataViewer', { action: 'read', target: f.name });
                    if (readRes.status === 'success') {
                        document.getElementById('drive-content').innerText = readRes.content;
                    }
                };
                
                list.appendChild(row);
            });
        }
    },

    // The Main Loop
    execute: async () => {
        const input = document.getElementById('input-source');
        const prompt = input.value.trim();
        if (!prompt) return;

        // 1. UI Feedback
        ui.print('USER', prompt);
        input.value = '';
        ui.print('SYS', 'Processing...', false, 'temp-loading');

        // 2. Pipeline Execution
        const res = await os.dispatch('PipelineEngine', { prompt: prompt });
        
        // Remove loading indicator
        const loader = document.getElementById('temp-loading');
        if (loader) loader.remove();

        if (res.status === 'success') {
            // 3. Render Response
            const data = res.data;
            ui.print('SYS', data.response);
            
            // 4. Update Stats
            os.state.stats.tokens += (data.tokens.count || 0);
            document.getElementById('token-counter').innerText = os.state.stats.tokens;

            // 5. Handle Delta (Live Memory Update)
            if (data.delta && Object.keys(data.delta).length > 0) {
                os.state.lastDelta = data.delta;
                ui.flashDelta();
                
                // Refresh full config in background to keep sync
                const confRes = await os.dispatch('ConfigManager', { action: 'get' });
                if (confRes.status === 'success') {
                    os.state.config = confRes.config;
                    ui.renderState();
                }
            }
            
            // 6. Add to Archive List
            ui.addArchiveItem(data.archive_id, prompt, data.intent);
        } else {
            ui.print('SYS', 'Error: ' + (res.message || 'Unknown Failure'), true);
        }
    }
};

/**
 * UI MANAGER
 * Handles DOM manipulation and Visual Feedback
 */
const ui = {
    print: (role, text, isError = false, id = null) => {
        const container = document.getElementById('terminal');
        const div = document.createElement('div');
        div.className = `line ${role.toLowerCase()}`;
        if (id) div.id = id;
        
        const safeText = text.replace(/</g, "&lt;").replace(/>/g, "&gt;");
        div.innerHTML = `
            <div class="meta">${role}</div>
            <div class="content mono" style="${isError ? 'color: #ff5252' : ''}">${safeText}</div>
        `;
        
        container.appendChild(div);
        // Auto Scroll
        const panel = document.getElementById('terminal-panel');
        panel.scrollTop = panel.scrollHeight;
    },

    renderState: () => {
        document.getElementById('state-display').innerText = JSON.stringify(os.state.config, null, 2);
        if (os.state.lastDelta) {
            document.getElementById('delta-display').innerText = JSON.stringify(os.state.lastDelta, null, 2);
        }
    },

    switchTab: (tabName) => {
        document.querySelectorAll('.tab').forEach(t => t.classList.remove('active'));
        document.querySelectorAll('.data-view').forEach(v => v.classList.remove('active'));
        
        event.target.classList.add('active');
        document.getElementById(`view-${tabName}`).classList.add('active');
    },

    setStatus: (type, active) => {
        const el = document.getElementById(`status-${type}`);
        if (active) el.classList.add('active');
        else el.classList.remove('active');
    },

    flashDelta: () => {
        const el = document.getElementById('view-delta');
        el.classList.add('delta-pulse');
        setTimeout(() => el.classList.remove('delta-pulse'), 1000);
        // Switch to delta view briefly if desired, or just flash button
    },

    addArchiveItem: (id, prompt, intent) => {
        const list = document.getElementById('archive-list');
        const item = document.createElement('div');
        item.style.padding = '10px';
        item.style.borderBottom = '1px solid #333';
        item.innerHTML = `
            <div style="color:var(--accent); font-size:0.7rem">${id}</div>
            <div style="color:white; margin: 4px 0">${prompt.substring(0, 30)}...</div>
            <div style="color:#666; font-size:0.7rem">Intent: ${intent}</div>
        `;
        list.prepend(item);
    }
};

// Boot
window.onload = os.init;

</script>
</body>
</html>