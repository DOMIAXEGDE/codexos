/**
 * @file gen_response_tokens.c
 * @brief Permutation Generator -> LLML .txt format (response tokens)
 *
 * Same as the prompt-token generator, but:
 *  - type: response_tokens
 *  - line role: response
 *  - tags: resp,auto
 */
#include <stdio.h>
#include <stdint.h>
#include <stdbool.h>
#include <limits.h>
#include <inttypes.h>
#include <string.h>

//==============================================================================
// 1. CONFIGURATION AND DATA DEFINITIONS
//==============================================================================

#define MAX_PERMUTATION_LENGTH 10
#define OUTPUT_FILENAME "llml-response-permutations.txt"

// LLML-ish defaults for RESPONSE lines
#define DEFAULT_ROLE   "response"
#define DEFAULT_WEIGHT "0.9"
#define DEFAULT_TAGS   "resp,auto"

// keep the same alphabet (no '\n')
static const char ALPHABET[] = {
    'a','b','c','d','e','f','g','h','i','j','k','l','m',
    'n','o','p','q','r','s','t','u','v','w','x','y','z',
    'A','B','C','D','E','F','G','H','I','J','K','L','M',
    'N','O','P','Q','R','S','T','U','V','W','X','Y','Z',
    '0','1','2','3','4','5','6','7','8','9',' '
};
static const uint64_t ALPHABET_SIZE = sizeof(ALPHABET) / sizeof(ALPHABET[0]);

//==============================================================================
// 2. OUTPUT SINK
//==============================================================================
typedef struct {
    void* context;
    bool (*write)(void* context, const char* buffer, uint64_t size);
    bool (*write_char)(void* context, char c);
} OutputSink;

static bool sink_write_str(OutputSink* sink, const char* s) {
    return sink->write(sink->context, s, (uint64_t)strlen(s));
}

static bool sink_write_line(OutputSink* sink, const char* s) {
    if (!sink_write_str(sink, s)) return false;
    return sink->write_char(sink->context, '\n');
}

//==============================================================================
// 3. CORE
//==============================================================================

static bool safe_uint64_power(uint64_t base, uint64_t exp, uint64_t* result) {
    *result = 1;
    for (uint64_t i = 0; i < exp; ++i) {
        if (*result > UINT64_MAX / base) {
            return false;
        }
        *result *= base;
    }
    return true;
}

static bool write_llml_header(OutputSink* sink,
                              uint64_t length,
                              uint64_t count)
{
    if (!sink_write_line(sink, "# llml-permutations")) return false;
    if (!sink_write_line(sink, "version: 1")) return false;
    if (!sink_write_line(sink, "type: response_tokens")) return false;  // <- changed
    if (!sink_write_line(sink, "generator: c-permutation-v1")) return false;

    {
        char buf[256];
        int n = snprintf(buf, sizeof(buf),
                         "meta: alphabet_size=%" PRIu64, ALPHABET_SIZE);
        if (n < 0) return false;
        if (!sink_write_line(sink, buf)) return false;
    }
    {
        char buf[128];
        int n = snprintf(buf, sizeof(buf),
                         "meta: length=%" PRIu64, length);
        if (n < 0) return false;
        if (!sink_write_line(sink, buf)) return false;
    }
    {
        char buf[256];
        int n = snprintf(buf, sizeof(buf),
                         "meta: count=%" PRIu64, count);
        if (n < 0) return false;
        if (!sink_write_line(sink, buf)) return false;
    }

    // blank line before data rows
    if (!sink_write_line(sink, "")) return false;
    return true;
}

static bool generate_response_permutations(uint64_t length, OutputSink* sink) {
    uint64_t num_combinations;
    if (!safe_uint64_power(ALPHABET_SIZE, length, &num_combinations)) {
        return false;
    }

    // header
    if (!write_llml_header(sink, length, num_combinations)) {
        return false;
    }

    char current_perm[MAX_PERMUTATION_LENGTH];
    char line_buf[1024];

    for (uint64_t i = 0; i < num_combinations; ++i) {
        uint64_t tmp = i;
        for (int64_t j = (int64_t)length - 1; j >= 0; --j) {
            uint64_t char_index = tmp % ALPHABET_SIZE;
            current_perm[j] = ALPHABET[char_index];
            tmp /= ALPHABET_SIZE;
        }

        // index|token|response|0.9|resp,auto
        int n = snprintf(
            line_buf,
            sizeof(line_buf),
            "%" PRIu64 "|%.*s|%s|%s|%s",
            (i + 1),
            (int)length,
            current_perm,
            DEFAULT_ROLE,
            DEFAULT_WEIGHT,
            DEFAULT_TAGS
        );
        if (n < 0 || n >= (int)sizeof(line_buf)) {
            return false;
        }

        if (!sink_write_line(sink, line_buf)) {
            return false;
        }
    }

    return true;
}

//==============================================================================
// 4. FILE SINK
//==============================================================================
static bool file_sink_write(void* context, const char* buffer, uint64_t size) {
    FILE* p = (FILE*)context;
    return fwrite(buffer, sizeof(char), size, p) == size;
}
static bool file_sink_write_char(void* context, char c) {
    FILE* p = (FILE*)context;
    return fputc(c, p) != EOF;
}
static bool file_sink_init(OutputSink* sink, const char* filename) {
    FILE* p = fopen(filename, "w");
    if (!p) return false;
    *sink = (OutputSink){
        .context = p,
        .write = file_sink_write,
        .write_char = file_sink_write_char
    };
    return true;
}
static void file_sink_close(OutputSink* sink) {
    if (sink && sink->context) {
        fclose((FILE*)sink->context);
        sink->context = NULL;
    }
}

//==============================================================================
// 5. MAIN
//==============================================================================
int main(void) {
    const uint64_t permutation_length = 1;  // adjust as needed

    if (permutation_length == 0 || permutation_length > MAX_PERMUTATION_LENGTH) {
        fprintf(stderr, "Invalid permutation length\n");
        return 1;
    }

    OutputSink sink;
    if (!file_sink_init(&sink, OUTPUT_FILENAME)) {
        perror("Error opening file");
        return 1;
    }

    bool ok = generate_response_permutations(permutation_length, &sink);
    file_sink_close(&sink);

    if (!ok) {
        fprintf(stderr, "Error generating response permutations\n");
        return 1;
    }

    return 0;
}
